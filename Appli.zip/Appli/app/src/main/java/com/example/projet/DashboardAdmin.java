package com.example.projet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class DashboardAdmin extends AppCompatActivity {

    private Button clicks;
    private Button grade;
    private Button badges;
    private Button frequence;
    private Button lock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_admin);

            MaterialButton loginbtn = (MaterialButton) findViewById(R.id.loginbtn);

            this.clicks = (Button) findViewById(R.id.loginbtn);

            clicks.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent Activity = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(Activity);
                    finish();
                }
            });

            this.grade = (Button) findViewById(R.id.grade);

            grade.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent Grade = new Intent(getApplicationContext(), Gradea.class);
                    startActivity(Grade);
                    finish();
                }
            });
            this.badges = (Button) findViewById(R.id.badge);

            badges.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent Badge = new Intent(getApplicationContext(), Badges.class);
                    startActivity(Badge);
                    finish();
                }
            });
            this.frequence = (Button) findViewById(R.id.frequence);

            frequence.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent Frequence = new Intent(getApplicationContext(), FrequencyA.class);
                    startActivity(Frequence);
                    finish();
                }
            });

            this.lock = (Button) findViewById(R.id.lockdown);

            lock.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent Lock = new Intent(getApplicationContext(), LockDown.class);
                    startActivity(Lock);
                    finish();
                }
            });
        }
    }


