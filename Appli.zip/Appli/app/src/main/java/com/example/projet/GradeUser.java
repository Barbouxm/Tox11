package com.example.projet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class GradeUser extends AppCompatActivity {

    private Button cancel5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade_user);

        this.cancel5 = (Button) findViewById(R.id.cancel5);

        cancel5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Cancel5 = new Intent(getApplicationContext(), DashboardUser.class);
                startActivity(Cancel5);
                finish();
            }
        });

    }
}