package com.example.projet;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Lock extends AppCompatActivity {

    private Button cancel7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock);

        this.cancel7 = (Button) findViewById(R.id.cancel7);

        cancel7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Cancel7 = new Intent(getApplicationContext(), DashboardUser.class);
                startActivity(Cancel7);
                finish();
            }
        });
    }
}