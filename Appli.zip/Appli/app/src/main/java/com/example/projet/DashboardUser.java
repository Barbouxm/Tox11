package com.example.projet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class DashboardUser extends AppCompatActivity {
    private Button clickable;

    private Button status;

    private Button time;

    private Button lock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_user);

        this.clickable = (Button) findViewById(R.id.loginbtn);

        clickable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent fourthActivity = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(fourthActivity);
                finish();
            }
        });

        this.status = (Button) findViewById(R.id.status);

        status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Status = new Intent(getApplicationContext(), GradeUser.class);
                startActivity(Status);
                finish();
            }
        });

        this.time = (Button) findViewById(R.id.time);

        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Time = new Intent(getApplicationContext(), Time.class);
                startActivity(Time);
                finish();
            }
        });

        this.lock = (Button) findViewById(R.id.lock);

        lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Lock = new Intent(getApplicationContext(), Lock.class);
                startActivity(Lock);
                finish();
            }
        });

    }
}
