package com.example.projet;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class SigninActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //lien avec la page layout
        setContentView(R.layout.activity_signin);
        //declaration des variables
        EditText id;
        EditText password;
        //mise en relation des variables avec le nom des boutons du xml
        id = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        boolean[] success = new boolean[1];
        int[] status = new int[1];
        final Button button = (Button) findViewById(R.id.loginbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Debut GET
                String username = id.getText().toString();
                String mdp = password.getText().toString();
                //URL API (Serveur Postman car pas d'API)
                String URL = "https://604b2979-c8ee-48c6-b891-52d89f8cd30e.mock.pstmn.io/connexion"+username+"&password="+mdp;

                StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //Gerer la réponse de la requête
                                if (response != null) {
                                    JSONObject jsonObject = null;
                                    try {
                                        jsonObject = new JSONObject(response);
                                        //Mise en relation avec l'API
                                        success[0] = jsonObject.getBoolean("success");
                                        status[0] = jsonObject.getInt("status");
                                        System.out.println("test:" + success[0]);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                                // Si l'utilisateur est enregistré dans la base de données
                                if (success[0])
                                {
                                    if (status[0] == 2) {
                                        //Redirection vers le Dashboard Admin
                                        Intent admin = new Intent(SigninActivity.this, DashboardAdmin.class);
                                        startActivity(admin);
                                    } else if (status[0] == 1) {
                                        //Redirection vers le Dashboard Utilisateur, Teacher, Manager
                                        Intent user = new Intent(SigninActivity.this, DashboardUser.class);
                                        user.putExtra("username",username);
                                        startActivity(user);

                                    }
                                }
                                // En cas de mot de passe ou identifiant erronés alors afficher le message suivant
                                else {
                                    Toast.makeText(SigninActivity.this, "Identifiant ou mot de passe incorrect", Toast.LENGTH_SHORT).show();
                                }
                            }

                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(SigninActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        });
                // Permettre d'excuter le code dans la page
                RequestQueue requestQueue = Volley.newRequestQueue(SigninActivity.this);
                requestQueue.add(stringRequest);
                // Fin de la requete GET
            }
        });
    }
}