package com.example.projet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class DashboardAdmin extends AppCompatActivity {

    private GridLayout gridLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_admin);

       gridLayout = findViewById(R.id.gridLayout);

       for (int i = 0; i<gridLayout.getChildCount(); i++) {
           final View childView = gridLayout.getChildAt(i);
           childView.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   int index = gridLayout.indexOfChild(childView);

                   String message = "Vue enfant cliquée :" + index;
                   Toast.makeText(DashboardAdmin.this, message, Toast.LENGTH_SHORT).show();

                   if(childView instanceof TextView) {
                       TextView textView = (TextView) childView;
                       textView.setText("Nouveau Texte");
                   }
               }
           });
       }

    }
}
